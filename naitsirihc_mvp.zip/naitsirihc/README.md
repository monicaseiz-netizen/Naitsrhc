# naitsirihc – kostenlose Web-App (MVP)

## Lokal testen
1. Entpacke die ZIP-Datei.
2. Öffne `index.html` im Browser.

## Was funktioniert
- Mobilfreundliche Startseite
- Beispielaktivitäten
- Suche und Kategorie-Filter
- Formular zum Eintragen von Aktivitäten
- Altersangabe (ab 13; nur Alter, kein Geburtsdatum)
- Optionales Feld für die Mitgliederzahl eines Vereins
- Bild- und Videodatei-Auswahl mit lokaler Vorschau
- Einträge werden lokal im Browser gespeichert

## Wichtige Grenzen dieser Demo
Die Einträge werden nur im jeweiligen Browser gespeichert. Andere Besucher sehen sie nicht.
Es gibt noch keine echten Nutzerkonten, Online-Datenbank, Anmeldung zu Aktivitäten oder privaten Chat. Bilder/Videos werden nur lokal als Vorschau gezeigt und nicht mitgespeichert oder online hochgeladen.
Bitte vor öffentlicher Nutzung echte Veranstaltungsdaten ergänzen und Datenschutz-/Moderationsregeln festlegen.

## Kostenlos veröffentlichen über GitHub Pages
1. Erstelle ein kostenloses Konto auf https://github.com/
2. Erstelle ein neues Repository, z. B. `naitsirihc`.
3. Lade `index.html` in das Repository hoch (Add file → Upload files → Commit changes).
4. Öffne im Repository Settings → Pages.
5. Wähle als Quelle `Deploy from a branch`, Branch `main`, Ordner `/ (root)`, dann Save.
6. Warte, bis GitHub Pages die Website veröffentlicht. Die Adresse wird normalerweise `https://DEIN-BENUTZERNAME.github.io/naitsirihc/` sein.

GitHub-Oberflächen und Bedingungen können sich ändern. Die Website ist öffentlich, sobald Pages aktiviert ist.
